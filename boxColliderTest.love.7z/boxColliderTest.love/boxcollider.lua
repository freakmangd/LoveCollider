-- collider Collider v0.5

local collider = {}
local collider = {}
local circle = {}

collider.boxes = {}
collider.boxIDs = {}

collider.circles = {}
collider.circleIDs = {}

function collider.newBox(x, y, width, height, tag, trigger, debugColor)

	local newBox = {}
	
	newBox.x = x
	newBox.y = y
	newBox.width = width or 50
	newBox.height = height or newBox.width
	newBox.tag = tag or 'none'
	newBox.trigger = trigger or false
	newBox.debugColor = debugColor or {1,1,1}
	
	newBox.ID = tostring(#collider.boxIDs+1)
	newBox.onTriggerEnter = function(collider) end
	newBox.onTriggerExit = function(collider) end
	newBox.collisions = {}
	newBox.lastFrameCollisions = {}
	
	newBox.superPoints = {
		{
			x = newBox.x,
			y = newBox.y
		},
		{
			x = newBox.x + newBox.width,
			y = newBox.y + newBox.height
		},
		
		updatePoint = function(point, x, y)
			newBox.superPoints[point].x = x
			newBox.superPoints[point].y = y
		end
	}
	
	function newBox.updatePos(newX, newY, center)
		center = center or true
	
		if center then
			newBox.x = newX - newBox.width/2
			newBox.y = newY - newBox.height/2
		else
			newBox.x = newX
			newBox.y = newY
		end
		
		newBox.superPoints.updatePoint(1, newBox.x, newBox.y)
		newBox.superPoints.updatePoint(2, newBox.x + newBox.width, newBox.y + newBox.height)
	end
	
	collider.boxes[newBox.ID] = newBox
	table.insert(collider.boxIDs, newBox.ID)
	
	return newBox

end

function collider.newCircle(x, y, radius, tag, trigger, debugColor)
	
	local newCircle = {}
	
	newCircle.x = x
	newCircle.y = y
	newCircle.radius = radius or 50
	newCircle.tag = tag or 'none'
	newCircle.trigger = trigger or false
	newCircle.debugColor = debugColor or {1,1,1}
	
	newCircle.ID = tostring(#collider.boxIDs+1)
	newCircle.onTriggerEnter = function(collider) end
	newCircle.onTriggerExit = function(collider) end
	newCircle.collisions = {}
	newCircle.lastFrameCollisions = {}
	
	function newCircle.updatePos(newX, newY)
		newCircle.x = newX
		newCircle.y = newY
	end
	
	collider.circles[newCircle.ID] = newCircle
	table.insert(collider.circleIDs, newCircle.ID)
	
	return newBox
	
end

function collider.update()	
	collider.updateBoxes()
end

function collider.draw()
	for k,id in ipairs(collider.boxIDs) do
		local v = collider.boxes[id]
		
		love.graphics.setColor(v.debugColor)
		love.graphics.rectangle('line', v.x, v.y, v.width, v.height)
		love.graphics.rectangle('fill', v.x + v.width/2 - (v.width/15)/2, v.y + v.height/2 - (v.height/15)/2, v.width/15, v.height/15)
		love.graphics.rectangle('fill', v.superPoints[1].x - (v.width/15)/2, v.superPoints[1].y - (v.height/15)/2, v.width/15, v.height/15)
		love.graphics.rectangle('fill', v.superPoints[2].x - (v.width/15)/2, v.superPoints[2].y - (v.height/15)/2, v.width/15, v.height/15)
	end
	
	for k,id in ipairs(collider.circleIDs) do
		local v = collider.circles[id]
		
		love.graphics.setColor(v.debugColor)
		love.graphics.circle('line', v.x, v.y, v.radius)
	end
end

function collider.updateBoxes()
	for k,v in ipairs(collider.boxIDs) do
		v = collider.boxes[v]
		
		for kk in pairs (v.collisions) do
			v.collisions[kk] = nil
		end
	end
	
	-- Check every collider for any collisions
	for k,my in ipairs(collider.boxIDs) do
		my = collider.boxes[my]
		
		-- Against every other collider		
		for kk,other in ipairs(collider.boxIDs) do
			other = collider.boxes[other]
			
			-- Ignore if it is yourself
			if kk ~= k then
				
				-- Look for an x plane and y plane intersection in superPoints
				local spX = {false, false}
				local spY = {false, false}
				
				-- Loop through superPoints
				for kkk,sp in ipairs(my.superPoints) do
					if sp.x > other.superPoints[1].x and sp.x < other.superPoints[2].x then
						spY[kkk] = true
					end
					
					if sp.y > other.superPoints[1].y and sp.y < other.superPoints[2].y then
						spX[kkk] = true
					end
				end
				
				--print(my.tag)
				--print('1: X: ' .. (spX[1] and 'true' or 'false') .. ' Y: ' .. (spY[1] and 'true' or 'false') .. ', \n2: X: ' .. (spX[2] and 'true' or 'false') .. ' Y: ' .. (spY[2] and 'true' or 'false') .. ' ')
				--print('\n')
				
				-- Check if superPoints show a collision between my and other
				if (spX[1] and spY[1]) or (spX[2] and spY[2]) or (spX[1] and spY[2]) or (spX[2] and spY[1]) then
					if not my.collisions[other.ID] ~= nil or not other.collisions[my.ID] ~= nil then
						my.collisions[other.ID] = other
						other.collisions[my.ID] = my
					end
				end
			end
		end
		
	end
	
	-- Update collision status
	for k,my in ipairs(collider.boxIDs) do
		my = collider.boxes[my]
		
		for kk,other in pairs(my.collisions) do
		
			-- Check if its a new collision
			if my.lastFrameCollisions[other.ID] == nil then
			
				my.lastFrameCollisions[other.ID] = other
				collider.boxes[other.ID].lastFrameCollisions[my.ID] = my
				
				my.onTriggerEnter(collider.boxes[other.ID])
				collider.boxes[other.ID].onTriggerEnter(my)
				
			end
		end
		
		for kk,other in pairs(my.lastFrameCollisions) do
		
			-- Check if collisions from last frame aren't there anymore
			if my.collisions[other.ID] == nil then
			
				my.lastFrameCollisions[other.ID] = nil
				collider.boxes[other.ID].lastFrameCollisions[my.ID] = nil
				
				my.onTriggerExit(collider.boxes[other.ID])
				collider.boxes[other.ID].onTriggerExit(my)
				
			end
		end
	end
end

return collider