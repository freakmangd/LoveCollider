-- Box Collider v0.1

local boxCollider = {}
boxes = {}

function boxCollider:new(x, y, width, height, tag, trigger, debugColor)

	newBox = {}
	
	newBox.x = x
	newBox.y = y
	newBox.width = width or 50
	newBox.height = height or newBox.width
	newBox.tag = tag or 'none'
	newBox.trigger = trigger or false
	newBox.debugColor = debugColor or {1,1,1}
	
	newBox.superPoints = {
		{
			x = 0,
			y = 0
		},
		{
			x = newBox.x + newBox.width,
			y = newBox.y + newBox.height
		}
	}
	
	function newBox.updatePos(newX, newY, center)
		center = center or true
	
		if center then
			newBox.x = newX - newBox.width/2
			newBox.y = newY - newBox.height/2
		else
			newBox.x = newX
			newBox.y = newY
		end
		
		newBox.superPoints = {
		{
			x = newBox.x,
			y = newBox.y
		},
		{
			x = newBox.x + newBox.width,
			y = newBox.y + newBox.height
		}
		}
	end
	
	table.insert(boxes, newBox)
	
	return newBox

end

function DrawBoxes()
	for k,v in ipairs(boxes) do
		love.graphics.setColor(v.debugColor)
		love.graphics.rectangle('line', v.x, v.y, v.width, v.height)
		love.graphics.rectangle('fill', v.x + v.width/2 - (v.width/15)/2, v.y + v.height/2 - (v.height/15)/2, v.width/15, v.height/15)
		love.graphics.rectangle('fill', v.superPoints[1].x - (v.width/15)/2, v.superPoints[1].y - (v.height/15)/2, v.width/15, v.height/15)
		love.graphics.rectangle('fill', v.superPoints[2].x - (v.width/15)/2, v.superPoints[2].y - (v.height/15)/2, v.width/15, v.height/15)
	end
end

return boxCollider