collider = require('boxCollider')

function love.load()
	box = collider.newBox(0, 0, 30, 30, 'Mouse')
	box.onTriggerEnter = function(collider)
		print("ENTER "..collider.ID)
	end
	box.onTriggerExit = function(collider)
		print("EXIT "..collider.ID)
	end
	
	box2 = collider.newBox(100, 100, 100, 100, 'Hello World', false, {1,0,0})
	box2.onTriggerEnter = function(collider)
		print("ENTER "..collider.ID)
	end
	box2.onTriggerExit = function(collider)
		print("EXIT "..collider.ID)
	end

	--circle = collider.newCircle(200, 100, 50)

end

function love.update(dt)
	box.updatePos(love.mouse.getPosition())
	
	collider.update()
end

function love.draw()
	collider.draw()
end