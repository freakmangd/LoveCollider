boxCollider = require('boxCollider')

function love.load()
	box = boxCollider:new(0, 0, 100)
end

function love.update(dt)
	box.updatePos(love.mouse.getPosition())
end

function love.draw()
	DrawBoxes()
end